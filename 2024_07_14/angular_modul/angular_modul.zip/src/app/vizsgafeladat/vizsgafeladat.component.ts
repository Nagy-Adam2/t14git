import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrl: './vizsgafeladat.component.css'
})
export class VizsgafeladatComponent {
  htmlModul!: number;
  bootstrapModul!: number;
  javaScriptModul!: number;
  typeScriptModul!: number;
  angularModul!: number;
  serverModul!: number;
  taroloLista: string[] = [];

  EredmenyMentes(): void {
    if (this.htmlModul === undefined) {
      alert("Az összes mező kitöltése kötelező!");
    } 
    else if (this.bootstrapModul === undefined) {
      alert("Az összes mező kitöltése kötelező!");
    }
    else if (this.javaScriptModul === undefined) {
      alert("Az összes mező kitöltése kötelező!");
    }
    else if (this.typeScriptModul === undefined) {
      alert("Az összes mező kitöltése kötelező!");
    }
    else if (this.angularModul === undefined) {
      alert("Az összes mező kitöltése kötelező!");
    }
    else if (this.serverModul === undefined) {
      alert("Az összes mező kitöltése kötelező!");
    }
    else {
      let vizsgalPontszam = this.htmlModul + this.bootstrapModul + this.javaScriptModul + this.typeScriptModul + this.angularModul + this.serverModul;
      if (vizsgalPontszam < 51) {
        this.taroloLista.push(`Sikertelen vizsga, szerzett pont: ${vizsgalPontszam}`);
      }
      else if (vizsgalPontszam < 59 && vizsgalPontszam >= 51) {
        this.taroloLista.push(`Sikeres vizsga (2-es), szerzett pont: ${vizsgalPontszam}`);
      }
      else if (vizsgalPontszam < 69 && vizsgalPontszam >= 60) {
        this.taroloLista.push(`Sikeres vizsga (3-as), szerzett pont: ${vizsgalPontszam}`);
      }
      else if (vizsgalPontszam < 79 && vizsgalPontszam >= 70) {
        this.taroloLista.push(`Sikeres vizsga (4-es), szerzett pont: ${vizsgalPontszam}`);
      }
      else if (vizsgalPontszam < 100 && vizsgalPontszam >= 80 ) {
        this.taroloLista.push(`Sikeres vizsga (5-ös), szerzett pont: ${vizsgalPontszam}`);
      }
      else {
        this.taroloLista.push(`Eredmény nem létezik, ezen a pontszámon: ${vizsgalPontszam}`);
      }
    }
  }
}