import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {
  primE!: number;
  primVizsgalat!: string;
  taroloLista: string[] = [];

  EredmenyMentes(): void {
    let oszto: number = 0;
    for(let i: number = 1; i <= this.primE; i++) {
      if(this.primE %i ==0) {
          oszto++;
        }
    }

    if (oszto == 2) {
      this.primVizsgalat = "A(z) " + this.primE + ": prím";
      this.taroloLista.push(this.primE + " prím");
    }
    else{
      this.primVizsgalat = "A(z) " + this.primE + ": NEM prím";
      this.taroloLista.push(this.primE + " NEM prím");
    }
  }
}
