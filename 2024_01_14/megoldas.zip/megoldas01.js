const myName = "Nagy Ádám";
const groupMember = "#Team14 Junior Frontend Fejlesztő + Webfejlesztő";
const htmlEducationalMaterial = 80;
const cssEducationalMaterial = 80;
const javascriptEducationalMaterial = 60;

document.write(`Nevem: ${myName} <br />`);
document.write(`Csoport azonosítóm: ${groupMember} <br />`);
document.write(`HTML tananyag ${htmlEducationalMaterial} <br />`);
document.write(`CSS tananyag ${cssEducationalMaterial} <br />`);
document.write(`JavaScript tananyag ${javascriptEducationalMaterial} <br />`);