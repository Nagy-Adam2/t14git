let number = Number(prompt("Add meg a életkort:"));

if (number > 0 && number <= 6) {
  document.write(`Életkora: ${number}, Kisgyermekkor`);
}
else if (number > 6 && number <= 12) {
  document.write(`Életkora: ${number}, Gyermekkor`);
}
else if (number > 12 && number <= 16) {
  document.write(`Életkora: ${number}, Serdülőkor`);
}
else if (number > 16 && number <= 20) {
  document.write(`Életkora: ${number}, Ifjúkor`);
}
else if (number > 20 && number <= 30) {
  document.write(`Életkora: ${number}, Fiatal felnőtt kor`);
}
else if (number > 30 && number <= 60) {
  document.write(`Életkora: ${number}, Felnőtt kor`);
}
else if (number > 60) {
  document.write(`Életkora: ${number}, Aggkor`);
}
else {
  document.write("Hiba");
}