let number = Number(prompt("Add meg a számot:"));
let divisor = Number(prompt("Add meg a osztót:"));

if (number % divisor == 0) {
  document.write(`Megadott számot ${number} osztja ${divisor}, úgy, hogy maradék a nulla`);
} else {
  document.write(`Megadott számot ${number} nem osztja ${divisor}, úgy, hogy maradék a nulla legyen`);
}