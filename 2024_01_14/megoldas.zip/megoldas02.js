const number = Number(prompt("Add meg egy számot"));
const pow = Number(prompt("Add meg a hatvány értékét"));

const result = number ** pow;
document.write(`Beírt szám ${number}, utána beírt hatvány érték ${pow}, aminek az eredménye ${result}`);