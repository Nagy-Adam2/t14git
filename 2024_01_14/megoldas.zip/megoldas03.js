let number = Number(prompt("Add meg kezdő számot:"));
let interval = Number(prompt("Add meg a generálás hosszát:"));

for(let i = 0; i < interval; i++) {
  number = number + 1;
  if (number%2 == 0) {
    document.write(number + "<br />");
  }
}