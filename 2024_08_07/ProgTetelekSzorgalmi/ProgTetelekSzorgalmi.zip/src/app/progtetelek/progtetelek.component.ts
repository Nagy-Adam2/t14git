import { Component } from '@angular/core';

@Component({
  selector: 'app-progtetelek',
  templateUrl: './progtetelek.component.html',
  styleUrl: './progtetelek.component.css'
})
export class ProgtetelekComponent {

  manualisErtek!: number;
  tombErtekek: number[] = [];
  ManualisErtekmegadas(): void {
    if (this.manualisErtek != null) {
      this.tombErtekek.push(this.manualisErtek);
    }
    else {
      alert("Az érték megadásda a feltöltésnél kötelező");
    }
  }

  elemSzam!: number;
  alsoHatar!: number;
  felsoHatar!: number;
  AutomatikusErtekmegadas(): void {
    if (this.elemSzam != null && this.alsoHatar != null && this.felsoHatar != null) {
      for (let i: number = 0; i < this.elemSzam; i++) {
        let generaltErtek = Math.round(Math.random() * (this.felsoHatar - this.alsoHatar)) + this.alsoHatar;
        this.tombErtekek.push(generaltErtek);
      }
    }
    else {
      alert("A generálási beállítások kitöltése kötelező!")
    }
  }

  elemekOsszege!: number;
  elemekAtlaga!: number;
  parosElemek!: number[];
  parosElemekSzama!: number;
  paratlanElemekSzama!: number;
  elemekMin!: number;
  elemekMinIndexe!: number;
  elemekMax!: number;
  elemekMaxIndexe!: number;


  ProgTetelek(): void {
    this.elemekOsszege = this.ElemekOsszege();
    this.elemekAtlaga = this.ElemekOsszege() / this.tombErtekek.length;
    this.parosElemek = this.ParosSzamokListaja();
    this.parosElemekSzama = this.parosElemek.length;
    this.paratlanElemekSzama = this.tombErtekek.length - this.parosElemek.length;
    this.elemekMin = this.ElemekMin();
    this.elemekMinIndexe = this.ElemekMinIndexe();
    this.elemekMax = this.ElemekMax();
    this.elemekMaxIndexe = this.ElemekMaxIndexe();
  }

  ElemekOsszege(): number {
    let osszeg: number = 0;
    for (let i = 0; i < this.tombErtekek.length; i++) {
      osszeg += this.tombErtekek[i];
    }
    return osszeg;
  }
  ParosSzamokListaja(): number[] {
    let parosak: number[] = [];
    for (let i = 0; i < this.tombErtekek.length; i++) {
      if (this.tombErtekek[i] % 2 == 0) {
        parosak.push(this.tombErtekek[i]);
      }
    }
    return parosak;
  }

  ElemekMin(): number {
    let minErtek: number = this.tombErtekek[0];
    for (let i = 0; i < this.tombErtekek.length; i++) {
      if(minErtek > this.tombErtekek[i]) {
        minErtek = this.tombErtekek[i];
      }
    }
    return minErtek;
  }

  ElemekMinIndexe(): number {
    let minErtekIndexe: number = this.tombErtekek[0];
    for (let i = 0; i < this.tombErtekek.length; i++) {
      if(minErtekIndexe > this.tombErtekek[i]) {
        minErtekIndexe = this.tombErtekek[i];
      }
    }
    let minIndex: number = this.tombErtekek.indexOf(minErtekIndexe);
    return minIndex;
  }

  ElemekMax(): number {
    let maxErtek: number = this.tombErtekek[0];
    for (let i = 0; i < this.tombErtekek.length; i++) {
      if(maxErtek < this.tombErtekek[i]) {
        maxErtek = this.tombErtekek[i];
      }
    }
    return maxErtek;
  }

  ElemekMaxIndexe(): number {
    let maxErtekIndexe: number = this.tombErtekek[0];
    for (let i = 0; i < this.tombErtekek.length; i++) {
      if(maxErtekIndexe < this.tombErtekek[i]) {
        maxErtekIndexe = this.tombErtekek[i];
      }
    }
    let maxIndex: number = this.tombErtekek.indexOf(maxErtekIndexe);
    return maxIndex;
  }

}