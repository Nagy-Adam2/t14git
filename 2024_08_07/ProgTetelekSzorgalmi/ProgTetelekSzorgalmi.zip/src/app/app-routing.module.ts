import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KezdolapComponent } from './kezdolap/kezdolap.component';
import { Hiba404Component } from './hiba404/hiba404.component';
import { ProgtetelekComponent } from './progtetelek/progtetelek.component';

const routes: Routes = [
  { path: "kezdolap", component: KezdolapComponent },
  { path: "hiba", component: Hiba404Component },
  { path: "progtetelek", component: ProgtetelekComponent },
  { path: "", redirectTo: "/kezdolap", pathMatch: "full" },
  { path: "**", component: Hiba404Component }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
