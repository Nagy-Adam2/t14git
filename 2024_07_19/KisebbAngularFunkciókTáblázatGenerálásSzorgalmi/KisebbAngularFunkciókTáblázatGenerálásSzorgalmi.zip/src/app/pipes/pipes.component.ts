import { Component } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrl: './pipes.component.css'
})
export class PipesComponent {
  mintaSzoveg: string = "Szeretem az angular!";
  mintaSzam: number = 42.314;
  mintaPenz: number = 500;
  aktDatum = new Date();
}
