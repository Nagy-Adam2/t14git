import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TablazatGeneralasComponent } from './tablazat-generalas/tablazat-generalas.component';

const routes: Routes = [
  { path: "tablazat-generalas", component: TablazatGeneralasComponent },
  { path: "", redirectTo: "/tablazat-generalas", pathMatch: "full" },
  { path: "**", component: TablazatGeneralasComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
