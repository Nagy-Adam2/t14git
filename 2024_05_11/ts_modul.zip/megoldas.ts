/*A megoldásodat ebben a fájlban készítsd el, majd fordítsd le typeScript compiler segítségével*/

/* 1. feladat: */

function  KivalasztottBetuk(vizsgaltSzoveg: string, kivalasztottBetuk: string[]): number {
	let kivalasztottBetukMennyiseg: number = 0;
    for(let i: number = 0; i < vizsgaltSzoveg.length; i++) {
        for(let j: number = 0; j < kivalasztottBetuk.length; j++) {
            if(vizsgaltSzoveg[i] == kivalasztottBetuk[j]) {
                kivalasztottBetukMennyiseg++;
            }
        }
    }
    return kivalasztottBetukMennyiseg;
}


KivalasztottBetuk("Sikerült a vizsga",['e','a','l']);




/* 2. feladat: */

function Szamtani(elsoErtek: number, masodikErtek: number, harmadikErtek: number): boolean {
    let szamtaniSorozatE: boolean = false;
	for(let i: number = 0; i < harmadikErtek; i++) {
        if((masodikErtek - elsoErtek) == (harmadikErtek - masodikErtek)){
            szamtaniSorozatE = true;      
        }
        else{
            szamtaniSorozatE = false;
        }  
    }
    return szamtaniSorozatE;
}


Szamtani(2, 4, 6);




/* 3. feladat: */

function VizsgaJegy(osszPont: number): string {
    if(osszPont >= 80 && osszPont <= 100) {
       return "Jeles";
    }
    else if(osszPont >= 70 && osszPont <= 79) {
        return "Jó";
    }
    else if(osszPont >= 60 && osszPont <= 69) {
        return "Közepes";
    }
    else if(osszPont >= 50 && osszPont <= 59) {
        return "Elégséges";
    }
    else if(osszPont >= 0 && osszPont <= 49) {
        return "Elégtelen";
    }
    else{
        return "HIBÁS ADAT!";
    }
}


VizsgaJegy(60);